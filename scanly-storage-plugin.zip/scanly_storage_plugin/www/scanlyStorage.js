var exec = require('cordova/exec');

module.exports = {
    savePdf: function (base64Data, fileName, success, error) {
        exec(success, error, 'ScanlyStorage', 'savePdf', [base64Data, fileName]);
    }
};
