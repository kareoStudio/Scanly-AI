package com.kareostudio.scanlystorage;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class ScanlyStorage extends CordovaPlugin {
    private static final int WRITE_PERMISSION_REQUEST = 4817;
    private CallbackContext pendingCallback;
    private String pendingBase64;
    private String pendingFileName;

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if (!"savePdf".equals(action)) return false;

        String base64 = args.optString(0, "");
        String fileName = sanitizeFileName(args.optString(1, "Scanned_Document.pdf"));
        if (base64.isEmpty()) {
            callbackContext.error("PDF data is empty.");
            return true;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveWithMediaStore(base64, fileName, callbackContext);
        } else {
            saveLegacy(base64, fileName, callbackContext);
        }
        return true;
    }

    private void saveWithMediaStore(String base64, String fileName, CallbackContext callbackContext) {
        cordova.getThreadPool().execute(() -> {
            Uri uri = null;
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                ContentResolver resolver = cordova.getActivity().getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Scanly AI");
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("Android could not create the Downloads file.");

                try (OutputStream output = resolver.openOutputStream(uri)) {
                    if (output == null) throw new Exception("Could not open the Downloads file.");
                    output.write(data);
                    output.flush();
                }

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
                callbackContext.success("Downloads/Scanly AI/" + fileName);
            } catch (Exception e) {
                if (uri != null) {
                    try { resolverDelete(uri); } catch (Exception ignored) { }
                }
                callbackContext.error(e.getMessage() == null ? "Could not save PDF." : e.getMessage());
            }
        });
    }

    private void resolverDelete(Uri uri) {
        cordova.getActivity().getContentResolver().delete(uri, null, null);
    }

    private void saveLegacy(String base64, String fileName, CallbackContext callbackContext) {
        if (ContextCompat.checkSelfPermission(cordova.getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            pendingCallback = callbackContext;
            pendingBase64 = base64;
            pendingFileName = fileName;
            ActivityCompat.requestPermissions(cordova.getActivity(),
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    WRITE_PERMISSION_REQUEST);
            return;
        }
        writeLegacy(base64, fileName, callbackContext);
    }

    private void writeLegacy(String base64, String fileName, CallbackContext callbackContext) {
        cordova.getThreadPool().execute(() -> {
            try {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists() && !downloads.mkdirs()) throw new Exception("Could not access Downloads folder.");
                File outFile = new File(downloads, fileName);
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                try (FileOutputStream output = new FileOutputStream(outFile)) {
                    output.write(data);
                    output.flush();
                }
                callbackContext.success("Downloads/" + fileName);
            } catch (Exception e) {
                callbackContext.error(e.getMessage() == null ? "Could not save PDF." : e.getMessage());
            }
        });
    }

    @Override
    public void onRequestPermissionResult(int requestCode, String[] permissions, int[] grantResults) throws JSONException {
        if (requestCode != WRITE_PERMISSION_REQUEST || pendingCallback == null) return;

        CallbackContext callback = pendingCallback;
        String base64 = pendingBase64;
        String fileName = pendingFileName;
        pendingCallback = null;
        pendingBase64 = null;
        pendingFileName = null;

        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            writeLegacy(base64, fileName, callback);
        } else {
            callback.error("Storage permission was denied.");
        }
    }

    private String sanitizeFileName(String name) {
        String clean = name == null ? "Scanned_Document.pdf" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!clean.toLowerCase().endsWith(".pdf")) clean += ".pdf";
        return clean;
    }
}
